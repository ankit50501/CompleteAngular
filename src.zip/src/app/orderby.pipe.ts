import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {
  transform(mobile:any, column:string, bool:boolean): any {
    
    if(column==undefined) {
      return mobile;
    }

    let result:any[];
    if(bool){
      result = this.ascending(mobile, column);
    }
    else{
      result = this.descending(mobile, column);

    }
    return result;
  }
  

  ascending(mobile:any[], column:string) {
    mobile.sort((first:any, second:any)=>{
      if(first[column] > second[column]){
        return 1;
      }
      else{
        return -1;
      }
    });


    return mobile;
  }


  descending(mobile: any, column: string): any[] {
    mobile.sort((first:any, second:any)=>{
      if(first[column] > second[column]){
        return -1;
      }
      else{
        return 1;
      }
    });
    return mobile;
  }

}
