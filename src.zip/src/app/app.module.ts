import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { FetchdataComponent } from './fetchdata/fetchdata.component';
import { AdddataComponent } from './adddata/adddata.component';
import { ServicService } from './servic.service';
import { AppRoutingModule } from './app-routing.module';
import { SearchdataComponent } from './searchdata/searchdata.component';
import { OrderbyPipe } from './orderby.pipe';

@NgModule({
  declarations: [
    AppComponent,
    FetchdataComponent,
    AdddataComponent,
    SearchdataComponent,
    OrderbyPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [HttpClient, ServicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
