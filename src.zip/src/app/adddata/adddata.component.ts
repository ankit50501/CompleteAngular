import { Component, OnInit } from '@angular/core';
import { ServicService, Employee } from '../servic.service';

@Component({
  selector: 'app-adddata',
  templateUrl: './adddata.component.html',
  styleUrls: ['./adddata.component.css']
})
export class AdddataComponent implements OnInit {

  service  : ServicService;
  emp : Employee[] = [];


  constructor(service : ServicService) {
    this.service = service;
   }

  ngOnInit() {
    this.emp = this.service.getData();
  }

  add(data : any){
    this.service.add(data);
  }

}
