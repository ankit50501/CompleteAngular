import { Component, OnInit } from '@angular/core';
import { ServivceService, Employee } from '../servivce.service';

@Component({
  selector: 'app-adding',
  templateUrl: './adding.component.html',
  styleUrls: ['./adding.component.css']
})
export class AddingComponent implements OnInit {

  service : ServivceService;
  emp : Employee[];

  constructor(service : ServivceService) {
    this.service = service;
   }

  ngOnInit() {
    this.service.fetchData();
    this.emp = this.service.getData();
  }

  delete(id){
    let check:number = -1;
    for(let i=0; i<this.emp.length; i++) {
      if(id == this.emp[i].id) {
        check = i;
        break;
      }
    }
    this.emp.splice(check, 1);
}
}
